# Rocket Studio

Rocket Studio is a South African fashion e-commerce storefront for men and women.

## Stack
- Next.js
- TypeScript
- React
- CSS

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Categories

### Women
Dresses, Tops, Hoodies, Bottoms, Sweat Pants, Jackets, Activewear, Shoes, Accessories.

### Men
T-Shirts, Shirts, Hoodies, Trousers, Sweat Pants, Jackets, Activewear, Shoes, Accessories.

### Shoes
Sneakers, Casual, Boots, Heels, Sandals, Formal.

Prices are displayed in South African Rand (ZAR).
