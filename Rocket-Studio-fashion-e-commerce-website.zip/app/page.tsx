const categories = [
  { name: "Women", image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1200&q=85" },
  { name: "Men", image: "https://images.unsplash.com/photo-1516826957135-700dedea698c?auto=format&fit=crop&w=1200&q=85" },
  { name: "Shoes", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=85" }
];

const products = [
  { name: "Essential Oversized Hoodie", price: "R899", category: "Women · Men", image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=85" },
  { name: "Everyday Runner", price: "R1,499", category: "Shoes", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=85" },
  { name: "Studio Sweat Pants", price: "R749", category: "Women · Men", image: "https://images.unsplash.com/photo-1552902865-b72c031ac5ea?auto=format&fit=crop&w=900&q=85" },
  { name: "Relaxed Street Tee", price: "R499", category: "Women · Men", image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=85" }
];

export default function Home() {
  return (
    <main>
      <div className="announcement">FREE DELIVERY ON ORDERS OVER R1,000 · SOUTH AFRICA</div>

      <header className="nav">
        <a className="logo" href="#">ROCKET<span>STUDIO</span></a>
        <nav>
          <a href="#new">NEW ARRIVALS</a>
          <a href="#women">WOMEN</a>
          <a href="#men">MEN</a>
          <a href="#clothing">CLOTHING</a>
          <a href="#shoes">SHOES</a>
          <a href="#sale">SALE</a>
        </nav>
        <div className="actions">
          <button aria-label="Search">⌕</button>
          <button aria-label="Account">♙</button>
          <button aria-label="Shopping bag">Bag (0)</button>
        </div>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">ROCKET STUDIO · 2026 COLLECTION</p>
          <h1>NEW ENERGY.<br /><em>NEW STYLE.</em></h1>
          <p className="hero-text">Contemporary clothing and footwear for every version of you.</p>
          <div className="hero-buttons">
            <a href="#women" className="button dark">SHOP WOMEN</a>
            <a href="#men" className="button light">SHOP MEN</a>
          </div>
        </div>
      </section>

      <section className="intro" id="new">
        <p className="eyebrow">THE ROCKET EDIT</p>
        <h2>Find your next favourite.</h2>
        <p>From everyday essentials to statement pieces, discover fresh styles designed to move with you.</p>
      </section>

      <section className="category-grid">
        {categories.map((category) => (
          <a className="category-card" key={category.name} href={`#${category.name.toLowerCase()}`}>
            <img src={category.image} alt={category.name} />
            <div><span>{category.name}</span><b>SHOP NOW →</b></div>
          </a>
        ))}
      </section>

      <section className="products" id="clothing">
        <div className="section-heading">
          <div><p className="eyebrow">JUST DROPPED</p><h2>New arrivals</h2></div>
          <a href="#">VIEW ALL →</a>
        </div>
        <div className="product-grid">
          {products.map((product) => (
            <article className="product" key={product.name}>
              <div className="product-image">
                <img src={product.image} alt={product.name} />
                <button className="heart" aria-label={`Add ${product.name} to wishlist`}>♡</button>
              </div>
              <p className="product-category">{product.category}</p>
              <h3>{product.name}</h3>
              <strong>{product.price}</strong>
            </article>
          ))}
        </div>
      </section>

      <section className="split" id="women">
        <div className="split-image"><img src="https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=1400&q=85" alt="Rocket Studio women's fashion" /></div>
        <div className="split-copy">
          <p className="eyebrow">WOMEN</p>
          <h2>Make it yours.</h2>
          <p>Hoodies, sweat pants, dresses, tops, jackets, activewear and more.</p>
          <a className="text-link" href="#">SHOP WOMEN →</a>
        </div>
      </section>

      <section className="split reverse" id="men">
        <div className="split-image"><img src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1400&q=85" alt="Rocket Studio men's fashion" /></div>
        <div className="split-copy">
          <p className="eyebrow">MEN</p>
          <h2>Built for your pace.</h2>
          <p>T-shirts, shirts, hoodies, sweat pants, trousers, jackets, activewear and more.</p>
          <a className="text-link" href="#">SHOP MEN →</a>
        </div>
      </section>

      <section className="newsletter">
        <p className="eyebrow">JOIN THE ROCKET</p>
        <h2>First access to new drops.</h2>
        <p>Sign up for new arrivals, exclusive offers and style inspiration.</p>
        <form><input type="email" placeholder="Your email address" aria-label="Email address" /><button type="submit">JOIN →</button></form>
      </section>

      <footer>
        <div className="footer-brand"><a className="logo" href="#">ROCKET<span>STUDIO</span></a><p>Fashion that moves with you.</p></div>
        <div><h4>SHOP</h4><a href="#">Women</a><a href="#">Men</a><a href="#">Shoes</a><a href="#">New Arrivals</a><a href="#">Sale</a></div>
        <div><h4>HELP</h4><a href="#">Contact</a><a href="#">Shipping</a><a href="#">Returns</a><a href="#">Size Guide</a></div>
        <div><h4>FOLLOW</h4><a href="#">Instagram</a><a href="#">TikTok</a><a href="#">Facebook</a></div>
      </footer>
      <div className="copyright">© 2026 Rocket Studio · South Africa · Prices shown in ZAR</div>
    </main>
  );
}
